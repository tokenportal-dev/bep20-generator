# BEP20 Token Generator

[![CI](https://github.com/vittominacori/bep20-generator/workflows/CI/badge.svg?branch=master)](https://github.com/vittominacori/bep20-generator/actions/)
[![Coverage Status](https://coveralls.io/repos/github/vittominacori/bep20-generator/badge.svg?branch=master)](https://coveralls.io/github/vittominacori/bep20-generator?branch=master)
[![MIT licensed](https://img.shields.io/github/license/vittominacori/bep20-generator.svg)](https://github.com/vittominacori/bep20-generator/blob/master/LICENSE)

The new Smart Contract Generator for BEP20 Token.

## Try it

[https://vittominacori.github.io/bep20-generator](https://vittominacori.github.io/bep20-generator)

## License

Code released under the [MIT License](https://github.com/vittominacori/bep20-generator/blob/master/LICENSE).
